

function cambiar(){
    var etiqueta = document.getElementsByTagName('title').innerHTML = "Prueba" ;


}


